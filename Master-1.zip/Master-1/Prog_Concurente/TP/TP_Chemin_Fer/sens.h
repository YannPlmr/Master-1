#ifndef _SENS_H_
#define _SENS_H_

/* Types */

typedef enum sens_s { OUEST_EST=0, EST_OUEST=1 } sens_t ;

/* Fonctions */

#endif
