#ifndef _SENS_STDIO_H_
#define _SENS_STDIO_H_

/* Types */

#include <sens.h>

/* Fonctions */

extern void sens_print( sens_t s ) ;
extern void sens_blanc_print() ;
extern void sens_vide_print() ;

#endif
