#ifndef _COMMUN_H_
#define _COMMUN_H_

#define LG_MAX_NOMPROG 128
#define max(a,b) (a>b ? a : b )

typedef enum boolean_s { B_FALSE , B_TRUE } boolean_t ;

#endif
