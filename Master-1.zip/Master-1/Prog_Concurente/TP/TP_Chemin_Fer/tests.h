#ifndef _TESTS_H_
#define _TESTS_H_

#define TEMPS_VOIR 5

#endif
