print(0.1+0.1+0.1)

print('%.40f' %0.1)

print('%.70f' %0.1)
