/* Module principal, qui chargera tous les modules nécessaires au déroulement
 du jeu et dans lequel est implémenté le predicat principal qui lance une
 partie, permet de choisir le mode jeu...*/
