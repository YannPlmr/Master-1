/*Module d'évaluation d'une position qui implémente tous os prédicats
nécessaires pour cette évaluation*/
