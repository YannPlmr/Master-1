/* Module de recherche du coup à jouer par l'ordinateur par l'algorithme
minimax*/
