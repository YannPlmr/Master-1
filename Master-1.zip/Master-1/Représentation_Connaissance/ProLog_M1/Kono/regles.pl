/*Module de modélisation des règles du jeu, dans lequel on trouera toutes les
fonctions dépendantes des règles du jeu choisi.*/
