cool(yolanda).
ecoute2LaMusique(mia).
ecoute2LaMusique(yolanda):- cool(yolanda).
joueAirGuitare(mia):- ecoute2LaMusique(mia).
joueAirGuitare(yolanda):- ecoute2LaMusique(yolanda).