f(a).
f(b).

g(a).
g(b).

h(b).

k(X):- f(X), g(X), h(X).